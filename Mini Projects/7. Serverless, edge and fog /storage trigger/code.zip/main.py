import os
import io  # To read from saved file
from google.cloud import storage, vision
import functions_framework

@functions_framework.cloud_event
def image_to_text_storage(cloud_event):
    client = storage.Client()
    data = cloud_event.data
    fileName = data ["name"]
    bucketName = data["bucket"]
    bucket = client.get_bucket(bucketName)
    blob = bucket.blob(fileName)
    if fileName.endswith(".txt"):
        return
    blob.download_to_filename(f'/tmp/{fileName}.jpg')

    client = vision.ImageAnnotatorClient()
    with io.open(f'/tmp/{fileName}.jpg', 'rb') as image_file:
        content = image_file.read()

    image = vision.Image(content=content)
    response = client.text_detection(image=image)
    text = response.full_text_annotation.text
    blob = storage.Blob(fileName.partition('.')[0]+".txt", bucket)
    blob.upload_from_string(text, content_type="text/plain")

    return